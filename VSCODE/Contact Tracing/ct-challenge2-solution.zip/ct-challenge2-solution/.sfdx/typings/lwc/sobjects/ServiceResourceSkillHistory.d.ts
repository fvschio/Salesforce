declare module "@salesforce/schema/ServiceResourceSkillHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ServiceResourceSkillHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ServiceResourceSkillHistory.ServiceResourceSkill" {
  const ServiceResourceSkill:any;
  export default ServiceResourceSkill;
}
declare module "@salesforce/schema/ServiceResourceSkillHistory.ServiceResourceSkillId" {
  const ServiceResourceSkillId:any;
  export default ServiceResourceSkillId;
}
declare module "@salesforce/schema/ServiceResourceSkillHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/ServiceResourceSkillHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/ServiceResourceSkillHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ServiceResourceSkillHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/ServiceResourceSkillHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/ServiceResourceSkillHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
