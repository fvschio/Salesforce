declare module "@salesforce/schema/SkillRequirementHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/SkillRequirementHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/SkillRequirementHistory.SkillRequirement" {
  const SkillRequirement:any;
  export default SkillRequirement;
}
declare module "@salesforce/schema/SkillRequirementHistory.SkillRequirementId" {
  const SkillRequirementId:any;
  export default SkillRequirementId;
}
declare module "@salesforce/schema/SkillRequirementHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/SkillRequirementHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/SkillRequirementHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/SkillRequirementHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/SkillRequirementHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/SkillRequirementHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
