declare module "@salesforce/schema/ResourceAbsenceHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ResourceAbsenceHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ResourceAbsenceHistory.ResourceAbsence" {
  const ResourceAbsence:any;
  export default ResourceAbsence;
}
declare module "@salesforce/schema/ResourceAbsenceHistory.ResourceAbsenceId" {
  const ResourceAbsenceId:any;
  export default ResourceAbsenceId;
}
declare module "@salesforce/schema/ResourceAbsenceHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/ResourceAbsenceHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/ResourceAbsenceHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ResourceAbsenceHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/ResourceAbsenceHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/ResourceAbsenceHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
