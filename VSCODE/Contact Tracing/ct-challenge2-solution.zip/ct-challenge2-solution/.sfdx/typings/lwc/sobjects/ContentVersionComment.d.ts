declare module "@salesforce/schema/ContentVersionComment.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContentVersionComment.ContentDocument" {
  const ContentDocument:any;
  export default ContentDocument;
}
declare module "@salesforce/schema/ContentVersionComment.ContentDocumentId" {
  const ContentDocumentId:any;
  export default ContentDocumentId;
}
declare module "@salesforce/schema/ContentVersionComment.ContentVersion" {
  const ContentVersion:any;
  export default ContentVersion;
}
declare module "@salesforce/schema/ContentVersionComment.ContentVersionId" {
  const ContentVersionId:any;
  export default ContentVersionId;
}
declare module "@salesforce/schema/ContentVersionComment.UserComment" {
  const UserComment:string;
  export default UserComment;
}
declare module "@salesforce/schema/ContentVersionComment.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
