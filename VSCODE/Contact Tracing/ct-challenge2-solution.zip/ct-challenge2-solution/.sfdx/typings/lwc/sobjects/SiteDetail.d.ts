declare module "@salesforce/schema/SiteDetail.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/SiteDetail.DurableId" {
  const DurableId:string;
  export default DurableId;
}
declare module "@salesforce/schema/SiteDetail.IsRegistrationEnabled" {
  const IsRegistrationEnabled:boolean;
  export default IsRegistrationEnabled;
}
declare module "@salesforce/schema/SiteDetail.SecureUrl" {
  const SecureUrl:string;
  export default SecureUrl;
}
