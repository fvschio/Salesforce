declare module "@salesforce/schema/ContentFolderLink.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContentFolderLink.ParentEntity" {
  const ParentEntity:any;
  export default ParentEntity;
}
declare module "@salesforce/schema/ContentFolderLink.ParentEntityId" {
  const ParentEntityId:any;
  export default ParentEntityId;
}
declare module "@salesforce/schema/ContentFolderLink.ContentFolder" {
  const ContentFolder:any;
  export default ContentFolder;
}
declare module "@salesforce/schema/ContentFolderLink.ContentFolderId" {
  const ContentFolderId:any;
  export default ContentFolderId;
}
declare module "@salesforce/schema/ContentFolderLink.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ContentFolderLink.EnableFolderStatus" {
  const EnableFolderStatus:string;
  export default EnableFolderStatus;
}
