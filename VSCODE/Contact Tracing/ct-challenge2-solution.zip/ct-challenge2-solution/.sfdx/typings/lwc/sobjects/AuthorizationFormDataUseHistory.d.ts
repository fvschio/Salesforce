declare module "@salesforce/schema/AuthorizationFormDataUseHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/AuthorizationFormDataUseHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/AuthorizationFormDataUseHistory.AuthorizationFormDataUse" {
  const AuthorizationFormDataUse:any;
  export default AuthorizationFormDataUse;
}
declare module "@salesforce/schema/AuthorizationFormDataUseHistory.AuthorizationFormDataUseId" {
  const AuthorizationFormDataUseId:any;
  export default AuthorizationFormDataUseId;
}
declare module "@salesforce/schema/AuthorizationFormDataUseHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/AuthorizationFormDataUseHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/AuthorizationFormDataUseHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/AuthorizationFormDataUseHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/AuthorizationFormDataUseHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/AuthorizationFormDataUseHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
