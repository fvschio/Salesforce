declare module "@salesforce/schema/ContentTagSubscription.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContentTagSubscription.User" {
  const User:any;
  export default User;
}
declare module "@salesforce/schema/ContentTagSubscription.UserId" {
  const UserId:any;
  export default UserId;
}
