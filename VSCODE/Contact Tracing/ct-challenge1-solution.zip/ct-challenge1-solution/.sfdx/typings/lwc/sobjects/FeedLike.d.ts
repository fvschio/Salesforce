declare module "@salesforce/schema/FeedLike.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/FeedLike.FeedItem" {
  const FeedItem:any;
  export default FeedItem;
}
declare module "@salesforce/schema/FeedLike.FeedItemId" {
  const FeedItemId:any;
  export default FeedItemId;
}
declare module "@salesforce/schema/FeedLike.FeedEntity" {
  const FeedEntity:any;
  export default FeedEntity;
}
declare module "@salesforce/schema/FeedLike.FeedEntityId" {
  const FeedEntityId:any;
  export default FeedEntityId;
}
declare module "@salesforce/schema/FeedLike.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/FeedLike.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/FeedLike.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/FeedLike.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/FeedLike.InsertedBy" {
  const InsertedBy:any;
  export default InsertedBy;
}
declare module "@salesforce/schema/FeedLike.InsertedById" {
  const InsertedById:any;
  export default InsertedById;
}
