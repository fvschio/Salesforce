declare module "@salesforce/schema/LightningUsageByAppTypeMetrics.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/LightningUsageByAppTypeMetrics.MetricsDate" {
  const MetricsDate:any;
  export default MetricsDate;
}
declare module "@salesforce/schema/LightningUsageByAppTypeMetrics.User" {
  const User:any;
  export default User;
}
declare module "@salesforce/schema/LightningUsageByAppTypeMetrics.UserId" {
  const UserId:any;
  export default UserId;
}
declare module "@salesforce/schema/LightningUsageByAppTypeMetrics.AppExperience" {
  const AppExperience:string;
  export default AppExperience;
}
declare module "@salesforce/schema/LightningUsageByAppTypeMetrics.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
