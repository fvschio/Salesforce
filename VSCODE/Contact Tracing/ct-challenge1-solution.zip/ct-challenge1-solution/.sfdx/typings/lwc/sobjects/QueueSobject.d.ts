declare module "@salesforce/schema/QueueSobject.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/QueueSobject.Queue" {
  const Queue:any;
  export default Queue;
}
declare module "@salesforce/schema/QueueSobject.QueueId" {
  const QueueId:any;
  export default QueueId;
}
declare module "@salesforce/schema/QueueSobject.SobjectType" {
  const SobjectType:string;
  export default SobjectType;
}
declare module "@salesforce/schema/QueueSobject.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/QueueSobject.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/QueueSobject.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
