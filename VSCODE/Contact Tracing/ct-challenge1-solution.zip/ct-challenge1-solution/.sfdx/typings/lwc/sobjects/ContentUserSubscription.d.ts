declare module "@salesforce/schema/ContentUserSubscription.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContentUserSubscription.SubscriberUser" {
  const SubscriberUser:any;
  export default SubscriberUser;
}
declare module "@salesforce/schema/ContentUserSubscription.SubscriberUserId" {
  const SubscriberUserId:any;
  export default SubscriberUserId;
}
declare module "@salesforce/schema/ContentUserSubscription.SubscribedToUser" {
  const SubscribedToUser:any;
  export default SubscribedToUser;
}
declare module "@salesforce/schema/ContentUserSubscription.SubscribedToUserId" {
  const SubscribedToUserId:any;
  export default SubscribedToUserId;
}
