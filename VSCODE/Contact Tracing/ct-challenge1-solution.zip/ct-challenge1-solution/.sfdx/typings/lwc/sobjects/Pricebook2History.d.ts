declare module "@salesforce/schema/Pricebook2History.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/Pricebook2History.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/Pricebook2History.Pricebook2" {
  const Pricebook2:any;
  export default Pricebook2;
}
declare module "@salesforce/schema/Pricebook2History.Pricebook2Id" {
  const Pricebook2Id:any;
  export default Pricebook2Id;
}
declare module "@salesforce/schema/Pricebook2History.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/Pricebook2History.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/Pricebook2History.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/Pricebook2History.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/Pricebook2History.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/Pricebook2History.NewValue" {
  const NewValue:any;
  export default NewValue;
}
