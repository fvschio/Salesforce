declare module "@salesforce/schema/AuthorizationFormTextHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/AuthorizationFormTextHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/AuthorizationFormTextHistory.AuthorizationFormText" {
  const AuthorizationFormText:any;
  export default AuthorizationFormText;
}
declare module "@salesforce/schema/AuthorizationFormTextHistory.AuthorizationFormTextId" {
  const AuthorizationFormTextId:any;
  export default AuthorizationFormTextId;
}
declare module "@salesforce/schema/AuthorizationFormTextHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/AuthorizationFormTextHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/AuthorizationFormTextHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/AuthorizationFormTextHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/AuthorizationFormTextHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/AuthorizationFormTextHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
