declare module "@salesforce/schema/OwnerChangeOptionInfo.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/OwnerChangeOptionInfo.DurableId" {
  const DurableId:string;
  export default DurableId;
}
declare module "@salesforce/schema/OwnerChangeOptionInfo.EntityDefinition" {
  const EntityDefinition:any;
  export default EntityDefinition;
}
declare module "@salesforce/schema/OwnerChangeOptionInfo.EntityDefinitionId" {
  const EntityDefinitionId:any;
  export default EntityDefinitionId;
}
declare module "@salesforce/schema/OwnerChangeOptionInfo.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/OwnerChangeOptionInfo.Label" {
  const Label:string;
  export default Label;
}
declare module "@salesforce/schema/OwnerChangeOptionInfo.IsEditable" {
  const IsEditable:boolean;
  export default IsEditable;
}
declare module "@salesforce/schema/OwnerChangeOptionInfo.DefaultValue" {
  const DefaultValue:boolean;
  export default DefaultValue;
}
declare module "@salesforce/schema/OwnerChangeOptionInfo.Parent" {
  const Parent:any;
  export default Parent;
}
declare module "@salesforce/schema/OwnerChangeOptionInfo.ParentId" {
  const ParentId:any;
  export default ParentId;
}
