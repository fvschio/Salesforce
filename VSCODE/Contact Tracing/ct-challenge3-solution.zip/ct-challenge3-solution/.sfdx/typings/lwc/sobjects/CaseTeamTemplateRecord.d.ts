declare module "@salesforce/schema/CaseTeamTemplateRecord.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CaseTeamTemplateRecord.Parent" {
  const Parent:any;
  export default Parent;
}
declare module "@salesforce/schema/CaseTeamTemplateRecord.ParentId" {
  const ParentId:any;
  export default ParentId;
}
declare module "@salesforce/schema/CaseTeamTemplateRecord.TeamTemplate" {
  const TeamTemplate:any;
  export default TeamTemplate;
}
declare module "@salesforce/schema/CaseTeamTemplateRecord.TeamTemplateId" {
  const TeamTemplateId:any;
  export default TeamTemplateId;
}
declare module "@salesforce/schema/CaseTeamTemplateRecord.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/CaseTeamTemplateRecord.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/CaseTeamTemplateRecord.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/CaseTeamTemplateRecord.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
