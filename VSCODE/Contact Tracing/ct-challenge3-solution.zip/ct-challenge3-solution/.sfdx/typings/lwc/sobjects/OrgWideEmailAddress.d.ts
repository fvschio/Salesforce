declare module "@salesforce/schema/OrgWideEmailAddress.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/OrgWideEmailAddress.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/OrgWideEmailAddress.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/OrgWideEmailAddress.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/OrgWideEmailAddress.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/OrgWideEmailAddress.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/OrgWideEmailAddress.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/OrgWideEmailAddress.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/OrgWideEmailAddress.Address" {
  const Address:string;
  export default Address;
}
declare module "@salesforce/schema/OrgWideEmailAddress.DisplayName" {
  const DisplayName:string;
  export default DisplayName;
}
declare module "@salesforce/schema/OrgWideEmailAddress.IsAllowAllProfiles" {
  const IsAllowAllProfiles:boolean;
  export default IsAllowAllProfiles;
}
