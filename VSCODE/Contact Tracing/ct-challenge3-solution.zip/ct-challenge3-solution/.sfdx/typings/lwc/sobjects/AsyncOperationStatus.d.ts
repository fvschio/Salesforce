declare module "@salesforce/schema/AsyncOperationStatus.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/AsyncOperationStatus.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/AsyncOperationStatus.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/AsyncOperationStatus.Fields" {
  const Fields:any;
  export default Fields;
}
declare module "@salesforce/schema/AsyncOperationStatus.Status" {
  const Status:string;
  export default Status;
}
declare module "@salesforce/schema/AsyncOperationStatus.Category" {
  const Category:string;
  export default Category;
}
declare module "@salesforce/schema/AsyncOperationStatus.Message" {
  const Message:string;
  export default Message;
}
declare module "@salesforce/schema/AsyncOperationStatus.StatusCode" {
  const StatusCode:string;
  export default StatusCode;
}
