declare module "@salesforce/schema/ServiceAppointmentHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ServiceAppointmentHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ServiceAppointmentHistory.ServiceAppointment" {
  const ServiceAppointment:any;
  export default ServiceAppointment;
}
declare module "@salesforce/schema/ServiceAppointmentHistory.ServiceAppointmentId" {
  const ServiceAppointmentId:any;
  export default ServiceAppointmentId;
}
declare module "@salesforce/schema/ServiceAppointmentHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/ServiceAppointmentHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/ServiceAppointmentHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ServiceAppointmentHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/ServiceAppointmentHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/ServiceAppointmentHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
