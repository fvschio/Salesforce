declare module "@salesforce/schema/SiteIframeWhiteListUrl.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/SiteIframeWhiteListUrl.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/SiteIframeWhiteListUrl.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/SiteIframeWhiteListUrl.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/SiteIframeWhiteListUrl.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/SiteIframeWhiteListUrl.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/SiteIframeWhiteListUrl.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/SiteIframeWhiteListUrl.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/SiteIframeWhiteListUrl.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/SiteIframeWhiteListUrl.Site" {
  const Site:any;
  export default Site;
}
declare module "@salesforce/schema/SiteIframeWhiteListUrl.SiteId" {
  const SiteId:any;
  export default SiteId;
}
declare module "@salesforce/schema/SiteIframeWhiteListUrl.Url" {
  const Url:string;
  export default Url;
}
