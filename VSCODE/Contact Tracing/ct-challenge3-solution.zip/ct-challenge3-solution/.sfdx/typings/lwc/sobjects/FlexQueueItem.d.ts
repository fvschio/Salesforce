declare module "@salesforce/schema/FlexQueueItem.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/FlexQueueItem.FlexQueueItemId" {
  const FlexQueueItemId:string;
  export default FlexQueueItemId;
}
declare module "@salesforce/schema/FlexQueueItem.JobType" {
  const JobType:string;
  export default JobType;
}
declare module "@salesforce/schema/FlexQueueItem.AsyncApexJob" {
  const AsyncApexJob:any;
  export default AsyncApexJob;
}
declare module "@salesforce/schema/FlexQueueItem.AsyncApexJobId" {
  const AsyncApexJobId:any;
  export default AsyncApexJobId;
}
declare module "@salesforce/schema/FlexQueueItem.JobPosition" {
  const JobPosition:number;
  export default JobPosition;
}
