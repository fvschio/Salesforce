declare module "@salesforce/schema/RemoteKeyCalloutEvent.ReplayId" {
  const ReplayId:string;
  export default ReplayId;
}
declare module "@salesforce/schema/RemoteKeyCalloutEvent.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/RemoteKeyCalloutEvent.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/RemoteKeyCalloutEvent.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/RemoteKeyCalloutEvent.StatusCode" {
  const StatusCode:string;
  export default StatusCode;
}
declare module "@salesforce/schema/RemoteKeyCalloutEvent.Details" {
  const Details:string;
  export default Details;
}
declare module "@salesforce/schema/RemoteKeyCalloutEvent.RequestIdentifier" {
  const RequestIdentifier:string;
  export default RequestIdentifier;
}
