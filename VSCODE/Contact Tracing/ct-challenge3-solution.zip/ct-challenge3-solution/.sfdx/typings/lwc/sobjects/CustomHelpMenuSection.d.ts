declare module "@salesforce/schema/CustomHelpMenuSection.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CustomHelpMenuSection.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/CustomHelpMenuSection.DeveloperName" {
  const DeveloperName:string;
  export default DeveloperName;
}
declare module "@salesforce/schema/CustomHelpMenuSection.Language" {
  const Language:string;
  export default Language;
}
declare module "@salesforce/schema/CustomHelpMenuSection.MasterLabel" {
  const MasterLabel:string;
  export default MasterLabel;
}
declare module "@salesforce/schema/CustomHelpMenuSection.NamespacePrefix" {
  const NamespacePrefix:string;
  export default NamespacePrefix;
}
declare module "@salesforce/schema/CustomHelpMenuSection.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/CustomHelpMenuSection.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/CustomHelpMenuSection.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/CustomHelpMenuSection.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/CustomHelpMenuSection.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/CustomHelpMenuSection.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/CustomHelpMenuSection.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
