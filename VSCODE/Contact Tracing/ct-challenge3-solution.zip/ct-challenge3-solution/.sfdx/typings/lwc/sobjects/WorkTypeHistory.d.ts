declare module "@salesforce/schema/WorkTypeHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/WorkTypeHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/WorkTypeHistory.WorkType" {
  const WorkType:any;
  export default WorkType;
}
declare module "@salesforce/schema/WorkTypeHistory.WorkTypeId" {
  const WorkTypeId:any;
  export default WorkTypeId;
}
declare module "@salesforce/schema/WorkTypeHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/WorkTypeHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/WorkTypeHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/WorkTypeHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/WorkTypeHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/WorkTypeHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
