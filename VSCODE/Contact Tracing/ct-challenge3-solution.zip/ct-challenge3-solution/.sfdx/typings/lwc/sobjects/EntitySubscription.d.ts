declare module "@salesforce/schema/EntitySubscription.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/EntitySubscription.Parent" {
  const Parent:any;
  export default Parent;
}
declare module "@salesforce/schema/EntitySubscription.ParentId" {
  const ParentId:any;
  export default ParentId;
}
declare module "@salesforce/schema/EntitySubscription.Subscriber" {
  const Subscriber:any;
  export default Subscriber;
}
declare module "@salesforce/schema/EntitySubscription.SubscriberId" {
  const SubscriberId:any;
  export default SubscriberId;
}
declare module "@salesforce/schema/EntitySubscription.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/EntitySubscription.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/EntitySubscription.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/EntitySubscription.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
