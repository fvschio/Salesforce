declare module "@salesforce/schema/ActiveScratchOrgHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ActiveScratchOrgHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ActiveScratchOrgHistory.ActiveScratchOrg" {
  const ActiveScratchOrg:any;
  export default ActiveScratchOrg;
}
declare module "@salesforce/schema/ActiveScratchOrgHistory.ActiveScratchOrgId" {
  const ActiveScratchOrgId:any;
  export default ActiveScratchOrgId;
}
declare module "@salesforce/schema/ActiveScratchOrgHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/ActiveScratchOrgHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/ActiveScratchOrgHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ActiveScratchOrgHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/ActiveScratchOrgHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/ActiveScratchOrgHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
